package com.example.stenopractice

import android.app.Activity
import android.os.Bundle
import android.os.CountDownTimer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.text.InputType
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var timer: CountDownTimer? = null
    private var seconds = 60
    private var currentText = "भारत एक लोकतांत्रिक गणराज्य है। संविधान प्रत्येक नागरिक को समान अधिकार प्रदान करता है। न्याय, स्वतंत्रता और समानता हमारे लोकतंत्र के प्रमुख आधार हैं।"
    private val passages = listOf(
        "भारत एक लोकतांत्रिक गणराज्य है। संविधान प्रत्येक नागरिक को समान अधिकार प्रदान करता है। न्याय, स्वतंत्रता और समानता हमारे लोकतंत्र के प्रमुख आधार हैं।",
        "न्यायालय का कार्य न्याय प्रदान करना तथा विधि के शासन को बनाए रखना है। प्रत्येक व्यक्ति को निष्पक्ष सुनवाई का अधिकार प्राप्त है।",
        "समय का सदुपयोग सफलता की कुंजी है। नियमित अभ्यास से गति और शुद्धता दोनों में सुधार होता है।"
    )
    private val words = listOf("न्यायालय", "संविधान", "स्वतंत्रता", "अधिकार", "प्रशासन", "न्यायाधीश", "अभियुक्त", "अधिवक्ता", "विवेचना", "प्रार्थना पत्र", "साक्ष्य", "कार्यवाही")
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var timerText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        home()
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("hi", "IN"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun home() {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(246,248,252)) }
        val header=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(22),dp(28),dp(22),dp(24)); setBackgroundColor(Color.rgb(24,62,140)) }
        header.addView(TextView(this).apply { text="STENO PRACTICE"; textSize=25f; setTextColor(Color.WHITE); setTypeface(null,1) })
        header.addView(TextView(this).apply { text="आपका दैनिक स्टेनो अभ्यास साथी"; textSize=15f; setTextColor(Color.WHITE); setPadding(0,dp(8),0,0) })
        root.addView(header)
        val scroll=ScrollView(this)
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(24)) }
        scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        addCard("🎧  डिक्टेशन अभ्यास","40–120 WPM पर सुनें और अभ्यास करें") { dictation() }
        addCard("⌨️  ट्रांसक्रिप्शन टेस्ट","सुनकर टाइप करें और अपना स्कोर देखें") { testScreen() }
        addCard("📚  हिंदी स्टेनो शब्द सूची","महत्वपूर्ण शब्दों का दैनिक अभ्यास") { dictionary() }
        addCard("📈  स्पीड एवं अभ्यास","WPM, समय और अभ्यास की जानकारी") { info() }
        root.addView(TextView(this).apply { text="Version 1.0 • Offline practice"; gravity=Gravity.CENTER; setTextColor(Color.GRAY); setPadding(0,dp(12),0,dp(18)) })
        setContentView(root)
    }
    private fun addCard(title:String, sub:String, action:()->Unit) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(18)); setBackgroundColor(Color.WHITE) }
        box.addView(TextView(this).apply { text=title; textSize=19f; setTextColor(Color.rgb(25,45,80)); setTypeface(null,1) })
        box.addView(TextView(this).apply { text=sub; textSize=14f; setTextColor(Color.DKGRAY); setPadding(0,dp(8),0,dp(12)) })
        box.addView(Button(this).apply { text="अभ्यास शुरू करें"; setOnClickListener{action()} })
        val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(12); content.addView(box,lp)
    }
    private fun page(title:String):LinearLayout {
        root.removeAllViews()
        val top=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(16),dp(18),dp(16)); setBackgroundColor(Color.rgb(24,62,140)) }
        top.addView(TextView(this).apply { text="‹  $title"; textSize=22f; setTextColor(Color.WHITE); setOnClickListener{home()} })
        root.addView(top)
        val sc=ScrollView(this); val body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(28)) }
        sc.addView(body); root.addView(sc,LinearLayout.LayoutParams(-1,0,1f)); return body
    }
    private fun dictation() {
        val b=page("डिक्टेशन अभ्यास")
        b.addView(label("डिक्टेशन की गति चुनें"))
        val sp=Spinner(this); sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("40 WPM","60 WPM","80 WPM","100 WPM","120 WPM")); b.addView(sp)
        val passage=TextView(this).apply { text=currentText; textSize=20f; setTextColor(Color.BLACK); setPadding(dp(12),dp(18),dp(12),dp(18)); setBackgroundColor(Color.WHITE) }
        b.addView(label("डिक्टेशन (शुरुआत में अभ्यास हेतु पाठ दिखेगा)")); b.addView(passage)
        b.addView(Button(this).apply { text="🔊  डिक्टेशन सुनें"; setOnClickListener { if(ttsReady) { val rate=(sp.selectedItemPosition+1)*0.45f+0.35f; tts.setSpeechRate(rate); tts.speak(currentText,TextToSpeech.QUEUE_FLUSH,null,"dictation") } else toast("Hindi Text-to-Speech उपलब्ध नहीं है") } })
        b.addView(Button(this).apply { text="अगला डिक्टेशन"; setOnClickListener { currentText=passages[(passages.indexOf(currentText)+1)%passages.size]; passage.text=currentText } })
        b.addView(label("टिप: पहले पाठ पढ़ें, फिर उसे छिपाकर सुनें और शॉर्टहैंड में लिखें।"))
    }
    private fun testScreen() {
        val b=page("ट्रांसक्रिप्शन टेस्ट")
        currentText=passages.random()
        b.addView(label("पहले डिक्टेशन सुनें, फिर नीचे टाइप करें।"))
        b.addView(Button(this).apply { text="🔊  पाठ सुनें"; setOnClickListener{if(ttsReady)tts.speak(currentText,TextToSpeech.QUEUE_FLUSH,null,"test")} })
        val input=EditText(this).apply { hint="यहाँ सुनकर टाइप करें…"; minLines=5; gravity=Gravity.TOP; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; setBackgroundColor(Color.WHITE); setPadding(dp(12),dp(12),dp(12),dp(12)) }
        b.addView(input,LinearLayout.LayoutParams(-1,dp(180)))
        timerText=label("समय: 60 सेकंड"); b.addView(timerText)
        b.addView(Button(this).apply { text="60 सेकंड टेस्ट शुरू करें"; setOnClickListener{startTimer()} })
        b.addView(Button(this).apply { text="उत्तर जाँचें"; setOnClickListener{checkAnswer(input.text.toString())} })
        b.addView(label("यह शुरुआती टेस्ट है; शुद्धता का स्कोर शब्दों के आधार पर अनुमानित है।"))
    }
    private fun startTimer() {
        timer?.cancel(); seconds=60; timerText.text="समय: 60 सेकंड"
        timer=object:CountDownTimer(60000,1000){override fun onTick(ms:Long){seconds=(ms/1000).toInt();timerText.text="समय: $seconds सेकंड"};override fun onFinish(){timerText.text="समय समाप्त!";toast("टेस्ट समाप्त")}}.start()
    }
    private fun checkAnswer(typed:String) {
        timer?.cancel()
        val a=currentText.trim().split(Regex("\\s+")).filter{it.isNotBlank()}
        val t=typed.trim().split(Regex("\\s+")).filter{it.isNotBlank()}
        val correct=a.zip(t).count{it.first==it.second}
        val accuracy=if(a.isEmpty())0 else (correct*100/a.size)
        AlertDialog.Builder(this).setTitle("आपका परिणाम").setMessage("मिलते-जुलते शब्द: $correct / ${a.size}\nअनुमानित शुद्धता: $accuracy%\nटाइप किए शब्द: ${t.size}").setPositiveButton("ठीक",null).show()
    }
    private fun dictionary() {
        val b=page("हिंदी शब्द सूची")
        b.addView(label("ये सामान्य हिंदी/न्यायालय शब्द हैं। इनके शॉर्टहैंड आउटलाइन स्वयं अभ्यास पुस्तिका से बनाएं।"))
        words.forEachIndexed{i,w->b.addView(TextView(this).apply{text="${i+1}.  $w";textSize=20f;setTextColor(Color.BLACK);setPadding(dp(12),dp(12),dp(12),dp(12));setBackgroundColor(if(i%2==0)Color.WHITE else Color.rgb(235,240,248)})}
    }
    private fun info() {
        val b=page("अभ्यास जानकारी")
        b.addView(label("दैनिक अभ्यास योजना"))
        listOf("10 मिनट – शब्द एवं Outline अभ्यास","15 मिनट – 60/80 WPM डिक्टेशन","10 मिनट – ट्रांसक्रिप्शन","5 मिनट – गलतियों की समीक्षा","हर सप्ताह अपनी स्पीड रिकॉर्ड करें").forEach{b.addView(label("• $it"))}
        b.addView(label("WPM = Words Per Minute (प्रति मिनट शब्द)। नियमित अभ्यास से गति और शुद्धता बढ़ती है।"))
    }
    private fun label(s:String)=TextView(this).apply{text=s;textSize=16f;setTextColor(Color.rgb(45,55,70));setPadding(dp(4),dp(12),dp(4),dp(12))}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    override fun onDestroy(){timer?.cancel();if(::tts.isInitialized)tts.shutdown();super.onDestroy()}
}
